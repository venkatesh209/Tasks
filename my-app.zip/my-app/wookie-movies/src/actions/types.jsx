//get Movies
export const GET_MOVIES = 'GET_MOVIES';

//get Genres
export const GET_GENRES = 'GET_GENRES'

//get Search Input
export const GET_SEARCH_INPUT = 'GET_SEARCH_INPUT'

//get Search Input
export const GET_MOVIE_INFO = 'GET_MOVIE_INFO'

// Movie Page
export const SET_LOADING_MOVIE_PAGE = 'SET_LOADING_MOVIE_PAGE'