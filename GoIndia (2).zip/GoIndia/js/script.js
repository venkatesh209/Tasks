document.addEventListener("DOMContentLoaded", function() {
    // Get elements
    var startButton = document.getElementById("startButton");
    var offcanvas = document.getElementById("offcanvas");
    var toggleButton = document.getElementById("toggleButton");
    var progress = document.getElementById("progress");

    // Variables
    var progressBarInterval;
    var progressBarWidth = 0;
    var progressBarIncrement = 1;

    // Start button click event
    startButton.addEventListener("click", function() {
      offcanvas.style.display = "block";
      progressBarInterval = setInterval(function() {
        progressBarWidth += progressBarIncrement;
        progress.style.width = progressBarWidth + "%";
        if (progressBarWidth >= 100) {
          clearInterval(progressBarInterval);
          offcanvas.style.display = "none";
          alert("Migration process completed.");
        }
      }, 50);
    });

    // Toggle button click event
    toggleButton.addEventListener("click", function() {
      if (progressBarInterval) {
        clearInterval(progressBarInterval);
        progressBarInterval = null;
      }
      offcanvas.style.display = offcanvas.style.display === "block" ? "none" : "block";
      if (offcanvas.style.display === "block") {
        progressBarInterval = setInterval(function() {
          progressBarWidth += progressBarIncrement;
          progress.style.width = progressBarWidth + "%";
          if (progressBarWidth >= 100) {
            clearInterval(progressBarInterval);
            offcanvas.style.display = "none";
            alert("Migration process completed.");
          }
        }, 50);
      }
    });
  });